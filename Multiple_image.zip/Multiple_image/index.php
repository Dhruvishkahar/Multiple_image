<!doctype html>
<html>
    <head>
        <link href="style.css" rel="stylesheet" type="text/css">
        <!-- <script src="jquery-3.0.0.js" type="text/javascript"></script> -->
        <!-- <script src="script.js" type="text/javascript"></script> -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    </head>
    <body >

        <div class="container" >
            <input type="file" name="file" id="file">

            <!-- Drag and Drop container-->
                <div class="upload-area"  id="uploadfile">
                    <h1>Drag and Drop file here<br/>Or<br/>Click to select file
                    </h1>
                </div>
                <div class="image">
                    <img src=""/>
                </div>

                <div>
                    <button class="upload">Upload</button>
                </div>
                <div class="msg"></div>
           </div>

    </body>
    <script>
    $(document).ready(function(){
            $("#uploadfile").click(function(){
            $("#file").click();
            });
            $('#file').change(function(){
                readURL(this);

            });
            function readURL(input) {
                if (input.files && input.files[0]) {
                    read_file(input.files);

                }
            }
            function read_file(files){
                var fd = new FormData();
                var reader = new FileReader();

                    reader.onload = function(e) {
                    $('.image img').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(files[0]);
                    var files = $('#file')[0].files[0];

                    fd.append('file',files);

                    uploadData(fd);
            }
            function uploadData(formData)
            {
                $('.upload').click(function(){
                    // alert();
                     // alert();
                $.ajax({
                    url:'upload.php',
                    type:'post',
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data){
                        alert(data);
                        $('.msg').html(data);
                    }
                });
                });

            }
            $(".upload-area").on('dragenter',function(e){
                event.preventDefault();
                event.stopPropagation();
             });
             $('.upload-area').on('dragover',function(e){
                event.preventDefault();
                event.stopPropagation();
             });
             $('.upload-area').on('drop',function(e){
                // alert();
                // e.stopPropagation();
                event.preventDefault();
                event.stopPropagation();
                //$("#image img").attr("src",e.target.result);
               // alert(e.target.result);
               var file=e.originalEvent.dataTransfer.files;
                console.log(file);

                read_file(file);
             });

    });
    </script>
</html>
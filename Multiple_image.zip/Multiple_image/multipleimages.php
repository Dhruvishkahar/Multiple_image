<!doctype html>
<html>
   <head>
      <link href="style.css" rel="stylesheet" type="text/css">
      <!-- <script src="jquery-3.0.0.js" type="text/javascript"></script> -->
      <!-- <script src="script.js" type="text/javascript"></script> -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
      <style>
         .pimage
         {
         display: inline-block;
         margin: 10px 10px 0 0;
         }
         .imageThumb {
         max-height: 75px;
         border: 2px solid;
         padding: 1px;
         cursor: pointer;
         }
         .remove {
         display: block;
         background: #444;
         border: 1px solid black;
         color: white;
         text-align: center;
         cursor: pointer;
         }
         .remove:hover {
         background: white;
         color: black;
         }
      </style>
   </head>
   <body >
      <div class="container" >
         <input type="file" name="imgfile[]" id="file" multiple>
         <!-- Drag and Drop container-->


               <div class="upload-area"  id="uploadfile">
                  <h4>Drag and Drop here Or<br/>select</h4>
               </div>

            <!-- <div class="btn">
            <button type="button" name="add"  class="btn btn-primary add btn">Add</button>
            </div> -->
         <div class="dvimage"></div>
         <div class="col text-center">
            <button class="btn btn-success upload">Upload</button>
            </div>
      </div>
   </body>
   <script>

      var cnttotalimage = 0;
      var timage = [];

      function reload_images(){
        $('.dvimage').empty();
            for(i=0;i<timage.length;i++)
            {

               //  console.log(fd);
                file_read(timage[i],i);
            }
      }

            $(document).on('click','.upload',function(){
               // alert();
               var fd =new FormData();
               for(i=0;i<timage.length;i++)
               {
                  fd.append('imgfile[]',timage[i]);
                  console.log(fd);
               }

               //    $.ajax({
               //       url:'multipleupload.php',
               //      type:'post',
               //      data: fd,
               //      contentType: false,
               //      processData: false,
               //      dataType: 'json',
               //      success: function(data){
               //          // alert(data);
               //          console.log(data);
               //          // $('.msg').html(data);
               //      }
               // });
            });


      function file_read(file,i)
      {
        var reader = new FileReader();

                 reader.onload = function(e) {

                     var html="";

                     html+='<span class="pimage"><img src="'+e.target.result+'" class="imageThumb" style="width:100px;height:100px;object-fit:cover;"  /><span class="remove" data-type="'+i+'">Delete</span></span>';
                     $('.dvimage').append(html);

                 }
                 reader.readAsDataURL(file);
                //  timage.length;
                //  console.log(timage);


      }
      $(document).ready(function(){
          $("#uploadfile").click(function(){
          $("#file").click();
          });
          $('#file').change(function(){
              readURL(this);
              reload_images();
          });
          function readURL(input) {
              if (input.files) {
                  read_file(input.files);

              }
          }
          function read_file(files){

              var filesAmount = files.length;
              for (i =0; i < filesAmount; i++) {
                    // console.log(i);
                    timage.push(files[i]);

              }
            //   console.log(timage);
          }
          $(document).on('click',".remove",function(){
                      // alert();
                      var id= $(this).attr('data-type');
                     //  alert(id);
                    // id.hide();
                    // removeByAttr(timage, 'id', 1);
                    timage.splice(id,1);
                    timage.length;
                    console.log(timage);

                    //   timage.delete(id);
                        $(this).parent(".pimage").remove();
                     });


          $(".upload-area").on('dragenter',function(e){
              event.preventDefault();
              event.stopPropagation();
           });
           $('.upload-area').on('dragover',function(e){
              event.preventDefault();
              event.stopPropagation();
           });
           $('.upload-area').on('drop',function(e){
              event.preventDefault();
              event.stopPropagation();
              var file=e.originalEvent.dataTransfer.files;
              reload_images();
              read_file(file);
           });

      });
   </script>
</html>
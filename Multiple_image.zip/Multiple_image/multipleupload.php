<?php
// var_dump($_FILES);
include 'dbconnect.php';
$countfiles = count($_FILES['imgfile']['name']);

 // Looping all files
 for($i=0;$i<$countfiles;$i++){
    $filename = uniqid().$_FILES['imgfile']['name'][$i];
    $filesize = $_FILES['imgfile']['size'][$i];
    $location = 'upload/'.$filename;
    move_uploaded_file($_FILES['imgfile']['tmp_name'][$i],$location);
    $src = $location;
    $sql  = "INSERT INTO `image`(`size`,`path`)VALUES('$filesize','$src')";
    $insert = $conn->query($sql);
    if($insert)
    {
        $ins = array("flag"=>1,"msg"=>'success','data'=>$insert);
    }
    else{
        $ins = array("flag"=>0,"msg"=>'error','data'=>null);
    }
  
}
echo json_encode($ins);

?>
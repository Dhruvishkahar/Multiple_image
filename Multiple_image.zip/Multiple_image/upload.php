<?php
include 'dbconnect.php';
$filename = uniqid().$_FILES['file']['name'];
$filesize = $_FILES['file']['size'];
$location = "upload/".$filename;
// $new_name = $location."-".rand()."-".$filename;
move_uploaded_file($_FILES['file']['tmp_name'],$location);
$src = $location;
$sql  = "INSERT INTO `image`(`size`,`path`)VALUES('$filesize','$src')";
$insert = $conn->query($sql);
if($insert)
{
    $ins = array("flag"=>1,"msg"=>'success','data'=>$insert);
}
else{
    $ins = array("flag"=>0,"msg"=>'error','data'=>null);
}
echo json_encode($ins);




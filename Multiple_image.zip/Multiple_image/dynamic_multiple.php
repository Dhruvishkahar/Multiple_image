<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiple</title>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <div class="col text-center">
        <button class=" btn btn-success add">Add</button>
    </div>
    <div class="imagetab"></div>
		<div class="col text-center">
        <button class="btn btn-primary upload">Upload</button>
    </div>
</div>
</body>
<script>
    var timage = [];
    $(document).ready(function () {
        var i = 0;
        $('.add').click(function () {
            i++;
            timage[i]=[];
		  $('.imagetab').append('<div class="dynamic' + i + '"><input type="file" name="imgfile[]" style="display:none;" class="file-main file'+i+'" data-type="'+i+'" multiple><div class="upload-area"  data-type="'+i+'"><h4>Drag and Drop here Or select</h4></div><div class="dvimage'+i+'"></div><div class="col text-right"><button  type="button"  data-type="'+i+'" name="remove" data-id="' + i + '" class="btn btn-danger btn_remove">Remove</button></div></div>');
		});
        $(document).on('click', '.btn_remove', function () {
		  var button_id = $(this).attr("data-id");
		  var btn_id = $(this).attr("data-type");
		//   timage[i].splice(button_id,1);
			timage[btn_id]=[];
			//timage.splice(timage[btn_id], 1);
		  $('.dynamic' + button_id + '').remove();
	   });
	   $(document).on('dragenter',".upload-area",function(e){
		//    console.log('drag');
			e.preventDefault();
               e.stopPropagation();
	   });
	   $(document).on('dragover','.upload-area',function(e){
		// console.log('drag');
			e.preventDefault();
               e.stopPropagation();
	   });
	   $(document).on('drop','.upload-area',function(e){
		// console.log('drop');
			var attr = $(this).attr('data-type');
              e.preventDefault();
              e.stopPropagation();
		    var file=e.originalEvent.dataTransfer.files;
		    read_file(file,attr);
              reload_images(attr);
	   });
        $(document).on('click', '.upload-area', function () {
            var attr = $(this).attr('data-type');
            $(".file"+attr).click();
        });
        $(document).on('change', '.file-main', function () {
           var attr = $(this).attr('data-type');
            // alert(attr);
            readURL(this,attr);
            reload_images(attr);
        });
        $(document).on('click', ".remove", function () {
            var id = $(this).attr('data-type');
            timage.splice(id, 1);
            timage.length;
            // console.log(timage);
            $(this).parent(".pimage").remove();
        });
        $(document).on('click','.upload',function(){
            // alert();
            var attr = $(this).attr('data-type');
            var fd = new FormData();
            var cnt  = 1;
            // console.log(timage);
            $.each(timage, function(key, value) {
                    if(value)
                    {
                        $.each(value,function(key,val){
                         //    console.log("val");
					//    console.log(val);

                            fd.append('imgfile['+cnt+'][]',val);
                        });
                    //     console.log("value");
                    //     console.log(value);
                        cnt++;
                    }
            });

            $.ajax({
                     url:'multipleimageupload.php',
                    type:'post',
                    data: fd,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data){
                        // alert(data);
                        console.log(data);
                        // $('.msg').html(data);
                    }
               });
        });
    });
    function readURL(input,attr) {
            if (input.files) {
                read_file(input.files,attr);

            }
        }

        function read_file(files,attr) {

            var filesAmount = files.length;
            for (i = 0; i < filesAmount; i++) {
                // console.log(i);
                timage[attr].push(files[i]);
                // console.log(timage);


            }
        }

        function reload_images(attr) {
            $('.dvimage'+attr).empty();
            for (i = 0; i < timage[attr].length; i++) {

                //  console.log(fd);
                file_read(timage[attr][i], i,attr);
                // console.log(timage[attr][i]);
            }
        }

        function file_read(file, i,attr) {
            var reader = new FileReader();

            reader.onload = function (e) {

                var html = "";

                html += '<span class="pimage"><img src="' + e.target.result + '" class="imageThumb" style="width:100px;height:100px;object-fit:cover;"  /><span class="remove" data-type="'+i+'">Delete</span></span>';
                // alert(attr);
                $(".dvimage"+attr).append(html);

            }
            reader.readAsDataURL(file);
            //  timage.length;
            //  console.log(timage);
        }
</script>
</html>

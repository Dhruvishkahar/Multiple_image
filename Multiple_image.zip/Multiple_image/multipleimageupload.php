<?php
// var_dump($_FILES);
include 'dbconnect.php';
// $countfiles = $_FILES['imgfile']['name'];
// var_dump($countfiles);
// var_dump($_FILES);
echo json_encode($_FILES);
foreach ($_FILES['imgfile']['name'] as $key => $value) {
    // $filename = $value];
    // var_dump($key);
    // var_dump($value);
    for ($i=0; $i <count($value) ; $i++) {
        // var_dump($value[$i]);

        // echo $value[$i]['imgfile'];
    }
            // echo $_FILES['imgfile']['tmp_name'][$value[$i]];

        // echo $_FILES['imgfile']['tmp_name'][$value[$i]][0];
        // $value['tmp_name'][$i];
        // var_dump($_FILES['imgfile']['tmp_name']);


}
// echo $_FILES['imgfile']['tmp_name'][2][1];
 // Looping all files
//  for($i=1;$i<$countfiles;$i++){
//     $filename = uniqid().$_FILES['imgfile']['name'][$i];
//     $filesize = $_FILES['imgfile']['size'][$i];
//     $location = 'upload/'.$filename;
//     move_uploaded_file($_FILES['imgfile']['tmp_name'][$i],$location);
//     $src = $location;
//     $sql  = "INSERT INTO `image`(`size`,`path`)VALUES('$filesize','$src')";
//     $insert = $conn->query($sql);
//     if($insert)
//     {
//         $ins = array("flag"=>1,"msg"=>'success','data'=>$insert);
//     }
//     else{
//         $ins = array("flag"=>0,"msg"=>'error','data'=>null);
//     }

// }
// echo json_encode($ins);

?>
<?php
$conn = new mysqli("localhost","root","","testing_demo");

?>